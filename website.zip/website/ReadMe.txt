1.Download node js
2.Donload mongodb and make sure to enable checkbox saying install mongodb compass it will be in last page of installation
3.then open cmd/terminal in this project directory
4.then type following command
	npm install
5.then to run code type following command
	node app.js

6.then visit url:
	localhost:3000



note:
ignore new and old folders inside models folders 
the files inside models are only important